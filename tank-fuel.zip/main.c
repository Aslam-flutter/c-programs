/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby,
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

float fuel=0;

void addFuel(float liters);
void useFuel(float liters);
void showFuelLevel();

int main()
{

	while(1) {
		int choice;
		float liters;
		printf("FUEL MANAGEMENT SYSTEM\n");
		printf("1) Add fuel\n2) Use fuel\n3) Show fuel\n4) Exit\nEnter your choice : ");
		scanf("%d",&choice);

		switch (choice) {
		case 1 :
			printf(" Fill fuel : ");
			scanf("%f",&liters);
			addFuel(liters);
			break;
		case 2 :
			printf(" use fuel : ");
			scanf("%f",&liters);
			useFuel(liters);
			break;
		case 3 :
			showFuelLevel();
			break;
		case 4 :
			return 0;
		default :
			printf("Invalid choice!\n");
		}
	}


}

void addFuel(float liters) {
	int s = fuel+liters;
	if (s<=50) {
		fuel+=liters;
		printf("Fuel added successfully : %.2f liters\n",liters);
	} else {
		printf("Fuel overflow!Tank capacity is only 50 liters.\n");
	}
}
void useFuel(float liters) {
	int s = fuel-liters;
	if (s<0) {
		printf("Not enough fuel!Tank is empty.\n");
	} else {
		fuel-=liters;
		printf("Fuel used successfully : %.2f liters\n",liters);
	}
}
void showFuelLevel() {
	printf("Fuel level is %.2f\n",fuel);
}