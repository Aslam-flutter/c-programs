/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby,
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int balance=5000,amount;

int checkPin();
void balanceEnquiry();
void deposit();
void withdraw();

int main()
{

	while(1) {
		int pin;
		printf("enter your pin : ");
		scanf("%d",&pin);
		  if (checkPin(pin) == 0) {
            return 0; 
        }


	}
}

int checkPin(int pin) {

	int choice,defPin=1234;
	if (defPin != pin) {
		printf("wrong pin\n");
	} else {
		printf(" 1) check balance \n 2) add money \n 3) withdraw money \n 4) exit from ATM \n enter your choice : ");
		scanf("%d",&choice);

		switch (choice) {
		case 1 :
			balanceEnquiry();
			break;
		case 2 :
			deposit();
			break;
		case 3 :
			withdraw();
			break;
		case 4 :
			printf("Thank you for using ATM\n");
			return 0;
		default:
			printf("wrong choice\n");
		}
	}


}


void balanceEnquiry() {
	printf("your balance is %d\n",balance);
}
void deposit() {
	printf("enter your amount : ");
	scanf("%d",&amount);
	if(amount>0) {
		balance+=amount;
		printf("amount debited succesfully\n");
		printf("updated balance : %d\n",balance);
	} else {
		printf("invalid amound\n");
	}
}
void withdraw() {
	printf("enter your amount : ");
	scanf("%d",&amount);
	if(amount>balance) {
		printf("insufficient balance\n");
	} else if (amount<0) {
		printf("invalid amount\n");
	} else {
		balance-=amount;
		printf("collect your cash\n");
		printf("remainig balance : %d\n",balance);
	}
}
