/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int size,arr[100];
    printf("enter the size of array: ");
    scanf("%d",&size);
    
     printf("enter the elements: ");
     for(int i =0;i<size;i++){
    scanf("%d",&arr[i]);
     }
     
     for(int i=1;i<size;i++){
         int key=arr[i];
         int j=i-1;
         
         while(j>=0 && arr[j]>key){
             arr[j+1]=arr[j];
             j=j-1;
         }
         arr[j+1]=key;
         
     }
    printf("sorted array :");
     for(int i =0;i<size;i++){
    printf("%d ",arr[i]);
     }
    
    int key,low=0,high=size-1,found=0;
    
    printf("\nenter the element to search: ");
    scanf("%d",&key);
    
    while(low<=high){
        int mid=(low+high)/2;
        if(arr[mid]==key){
            printf("element found in %d index",mid);
            found=1;
            break;
        }else if(arr[mid]<key){
            low=mid+1;
        }else{
            high=mid-1;
        }
    }
    
    if(found == 0){
        printf("not found");
    }

    return 0;
}
