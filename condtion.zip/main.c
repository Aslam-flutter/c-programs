/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
	int a = 49;
	int b = 50;

	if(a > b) {
		printf("a is greater than b\n");
	} else if(a == b) {
	    printf("those are equal\n");
	}else{
		printf("b is greater than a\n");
    }


return 0;
}
