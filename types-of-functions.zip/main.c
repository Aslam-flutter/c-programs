/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby,
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int i = 10; // global scope
int j = 20; // global scope

void addNum(int a, int b) { // fn without return type with parameter
	int c = a+b; // local scope
	printf("1. Added result is %d\n",c);
}

int substNum(int a, int b) { // fn with return type with parameter
	int c = a-b; // local scope
// 	printf("Substracted Value is %d",c);
	return c;
}

void multNum(){ // fn without return type without parameter
    i = 25;
    j = 3;
    int c = i*j; // local scope
    printf("3. Multiplied redult is %d\n",c);
}

int divNum(){ // fn without return type without parameter
    i = 50;
    j = 3;
    int c = i/j; // local scope
    return c;
}





int main()
{
	addNum(12,23);
	printf("2. The result is %d\n", substNum(20,10));
	multNum();
	printf("4. Divided result is %d",divNum());




	return 0;
}

