/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/

// --VARIABLES--DATATYPES--FORMAT SPECIFIERS--COMMENTS

/*     -- HELLO--   */

#include <stdio.h>

int main(){

    int a = 65;
    char b = 'A';
    float c = 10.56565656;
    double d = 3.767676767667; // IT IS DOUBLE VARIABLE
 
    
    printf("I have entered %i\n",a);
    printf("I have entered %c\n",b);
    printf("I have entered %.1f\n",c);
    printf("I have entered %F\n",d);
    
}
