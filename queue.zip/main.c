/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#define size 5

int arr[size],front=-1,back=-1;

void enque();
void deque();
void top();
void display();

int main()
{
	while(1) {
		int choice;
		printf("1) Enque\n2) Deque\n3) Top\n4) Display\n5) Exit\nEnter your choice : ");
		scanf("%d",&choice);

		switch (choice) {
		case 1:
			enque();
			break;
		case 2:
			deque();
			break;
		case 3:
			top();
			break;
		case 4:
			display();
			break;
		case 5:
			printf("Program closed.");
			return 0;
			break;
		default:
			printf("Invalid choice...");
		}


	}
}

void enque() {


	if(back == size-1) {
		printf("Queue is full...\n");
	} else {
		int number;
		printf("Enter element to enque: ");
		scanf("%d",&number);

		if(front == -1) {
			front = 0;
		}
		back++;
		arr[back]=number;
		printf("You enqued %d to Queue\n",number);
	}


}

void deque() {
	if(front == -1 || front>back) {
		printf("Queue is empty...\n");
	} else {
		printf("You dequed %d from Queue\n",arr[front]);
		front++;
	}
}

void top() {
	if(front==-1 || front>back) {
		printf("Queue is empty...\n");
	} else {
		printf("Top element in front is %d and back id %d\n",arr[front],arr[back]);
	}
}

void display() {
	if(front == -1 || front>back ) {
		printf("Queue is empty...\n");
	} else {
		printf("Elements in queue : ");
		for(int i=front; i<=back; i++) {
			printf("%d ",arr[i]);
		}
		printf("\n");
	}
}