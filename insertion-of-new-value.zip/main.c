/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int size,arr[100],position,newElement;
    printf("Enter the size of array : ");
    scanf("%d",&size);
    
    printf("Enter the elements : ");
    for(int i=0;i<size;i++){
        scanf("%d",&arr[i]);
    }
    
    printf("Enter the position to insert : ");
    scanf("%d",&position);
    
     printf("Enter the element to insert : ");
    scanf("%d",&newElement);
    
    for(int i=size-1;i>=position-1;i--){
        arr[i+1]=arr[i];
    }
    size++;
    arr[position-1]=newElement;
    
    for(int i=0;i<size;i++){
        printf("%d ",arr[i]);
    }

    return 0;
}