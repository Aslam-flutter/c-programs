/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int size,arr[100],position;
    printf("Enter the size of array : ");
    scanf("%d",&size);
    
    printf("Enter the elements : ");
    for(int i=0;i<size;i++){
        scanf("%d",&arr[i]);
    }
    
    printf("Enter the position to delete : ");
    scanf("%d",&position);
    
    for(int i=position-1;i<size;i++){
        arr[i]=arr[i+1];
    }
    size--;
    
    for(int i=0;i<size;i++){
        printf("%d ",arr[i]);
    }

    return 0;
}