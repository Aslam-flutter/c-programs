/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby,
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int stock=100;

void addStock(int qty) {
	if (qty>0) {
		stock+=qty;
		printf("Stock added successfully.\n");
		printf("Added %d items to stock.\n", qty);

	} else {
		printf("Insufficient quantity! Cannot add.\n");

	}
}

void sellStock(int qty) {
	if (stock>qty) {
		stock-=qty;
		printf("Stock sold successfully.\n");
		printf("Sold %d items from stock.\n", qty);

	} else {
		printf("Not enough stock available to sell.\n");

	}
}

void showStock() {
	printf("Current stock: %d items\n", stock);


}

int main()
{
	while(1) {
		int option,qty;
		printf("Click 1 to add stock\n");
		printf("Click 2 to sell stock\n");
		printf("Click 3 to show stock\n");
		printf("Click 4 to exit\n");
		scanf("%d",&option);

		switch (option) {
		case 1 :
			printf("Enter quantity to add to stock: ");
			scanf("%d",&qty);
			addStock(qty);
			break;
		case 2 :
			printf("Enter quantity to sell: ");
			scanf("%d",&qty);
			sellStock(qty);
			break;
		case 3 :
			showStock();
			break;
		case 4 :
			return 0;
			break;
		default :
			printf("Invalid option!");
		}
	}
}