/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
// Convert Celsius to Fahrenheit.

#include <stdio.h>

int main()
{
   float F,C;
   printf("Celsius to Fahrenheit Converter\n");
   printf("enter Celsius : ");
   scanf("%f",&C);
   F=(C*9.0/5.0)+32;
   printf("Fahrenheit : %.2f",F);
   
   return 0;
}
