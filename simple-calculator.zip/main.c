/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int num1,num2,choice;
    printf("enter 2 numbers: ");
    scanf("%d %d",&num1,&num2);
    printf("1) add\n2) substraction\n3) multiplication\n4) division\nEnter your choice : ");
    scanf("%d",&choice);
    if (choice == 1){
        printf("result = %d",num1+num2);
    }else if (choice == 2){
        printf("result = %d",num1-num2);
    }else if (choice == 3){
        printf("result = %d",num1*num2);
    }else if (choice == 4){
        printf("result = %d",num1/num2);
    }else{
        printf("Wrong choice");
    }




    return 0;
}
