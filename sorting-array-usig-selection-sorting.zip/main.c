/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int size,arr1[100];
    printf("Enter the size of array : ");
    scanf("%d",&size);
    
    printf("Enter the elements : ");
    for(int i=0;i<size;i++){
        scanf("%d",&arr1[i]);
    }
    
     printf("Array before sorting : ");
    for(int i=0;i<size;i++){
        printf("%d ",arr1[i]);
    }
    
    for(int i=0;i<size;i++){
            for(int j=i+1;j<size;j++){
                if(arr1[i]>arr1[j]){
                    int temp=arr1[i];
                    arr1[i]=arr1[j];
                    arr1[j]=temp;
                }    
            }
        }
    
    printf("\nArray after sorting : ");
    for(int i=0;i<size;i++){
        printf("%d ",arr1[i]);
    }
    
    return 0;
}
