/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
   int i = 1; // initialization
   printf("program started\n\n");
   while(i<=5){  // condition
       printf("Aslam\n"); //if true work statement
       i++; //i = i+1;  // increment
   }
   printf("\nprogram ended");

    return 0;
}
