/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int size;
    int arr[100];
    
    printf("enter the size of array: ");
    scanf("%d",&size);
    
    printf("enter the elements of the array: ");
    for(int i=0;i<size;i++){
        scanf("%d",&arr[i]);
    }
    
    // int size = sizeof(arr)/sizeof(arr[0]);
    
    for(int i=0;i<size;i++){
    //   if(arr[i]%2==0){
           printf("%d   ",arr[i]);
    //   }
    }

    return 0;
}