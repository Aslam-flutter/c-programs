/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
   int size,arr[100];
   printf("Enter the size of the array: ");
   scanf("%d",&size);
   
   printf("Enter the elements of the array: ");
   for(int i=0;i<size;i++){
       scanf("%d",&arr[i]);
       }
    int even=0,odd=0;    
    for(int i=0;i<size;i++){
        if(arr[i] % 2 == 0){
            even++;
        }else{
            odd++;
        }
    }
    printf("odd numbers is %d, even numbers is %d",odd,even);
       
}