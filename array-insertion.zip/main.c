/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int size,arr[100],position,value;
    printf("enter the the size of array: ");
    scanf("%d",&size);
    printf("enter the elements: ");
    for(int i=0;i<size;i++){
        scanf("%d",&arr[i]);
    }
    printf("enter the position of new value: ");
    scanf("%d",&position);
    printf("enter value: ");
    scanf("%d",&value);
    
    for(int i=size-1;i>=position-1;i--){
        arr[i+1]=arr[i];
    }
    arr[position-1]=value;
    size++;
    
    for(int i=0;i<size;i++){
        printf("%d    ",arr[i]);
    }
    
    
    return 0;
}