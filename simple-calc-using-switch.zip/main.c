/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int num1,num2,choice;
    printf("enter 2 numbers: ");
    scanf("%d %d",&num1,&num2);
    printf("1) add\n2) substraction\n3) multiplication\n4) division\nEnter your choice : ");
    scanf("%d",&choice);
    
    switch(choice){
        case 1:
        printf("the result is %d",num1+num2);
        break;
        case 2:
        printf("the result is %d",num1-num2);
        break;
        case 3:
        printf("the result is %d",num1*num2);
        break;
        case 4:
        printf("the result is %d",num1/num2);
        break;
        default:
        printf("invalid choice");
    }

    return 0;
}
