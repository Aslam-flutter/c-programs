/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#define size 5


int array[size];
int top = -1;


void push();
void pop();
void peek();
void display();


int main()
{

	while(1) {
		int choice;
		printf("1. Push\n2. Pop\n3. Peek\n4. Display\n5. Exit\nEnter your choice: ");
		scanf("%d",&choice);


		switch(choice) {
		case 1:
			push();
			break;
		case 2:
            pop();
			break;
		case 3:
            peek();
			break;
		case 4:
            display();
			break;
		case 5:
            printf("Program stopped..\n");
            display();
			break;
		default:
			printf("invalid choice....\n");


		}
	}


	return 0;
}

void push() {
	if(top == size-1) {
		printf("the stack is full...\n");
	} else {
		int number;

		printf("Enter number to push: ");
		scanf("%d",&number);

		top++;
		array[top] = number;
		printf("you pushed %d on the stack\n",number);
	}


}



void pop(){
    if(top == -1){
        printf("Stack is Empty....\n");
    }else{
        printf("Element %d popped form stack..\n",array[top]);
        top--;
    }
}

void peek(){
    if(top == -1){
        printf("Stack is Empty....\n");
    }else{
        printf("Element %d is on top of stack..\n",array[top]);
    }
}

void display(){
    if(top == -1){
        printf("Stack is Empty....\n");
    }else{
        printf("Elements in stack are:  ");
       for(int i=0;i<=top;i++){
           printf("%d  ",array[i]);
       }
       printf("\n");
    }
}


