/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby,
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
	int arr[100],size;
	printf("enter the size of array :");
	scanf("%d",&size);
	printf("enter numbers: ");
	for(int i=0; i<size; i++) {
		scanf("%d",&arr[i]);

		for(int i=1; i<size; i++) {
			int key=arr[i];
			int j=i-1;

			while(j>=0 && arr[j]>key) {
				arr[j+1]=arr[j];
				j=j-1;
			}
			arr[j+1]=key;
		}

	}
	for(int i=0; i<size; i++) {
		printf("%d ",arr[i]);
	}
}