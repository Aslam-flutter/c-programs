/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int size,arr1[100],arr2[100];
    printf("Enter the size of array : ");
    scanf("%d",&size);
    
    printf("Enter the elements : ");
    for(int i=0;i<size;i++){
        scanf("%d",&arr1[i]);
    }
    
    for(int i=0;i<size;i++){
            arr2[i]=arr1[i];
            }
    
    printf("Elements of 1st array : ");
    for(int i=0;i<size;i++){
        printf("%d ",arr1[i]);
    }
    
     printf("\n\nElements of 2nd array : ");
    for(int i=0;i<size;i++){
        printf("%d ",arr2[i]);
    }
    
    return 0;
}
