/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int balance=0;
void deposit();
void withdraw();

int main()
{

	while (1) {
		int choice,money;
		printf(" 1) check balance \n 2) add money \n 3) withdraw money \n 4) exit from bank \n enter your choice : ");
		scanf("%d",&choice);

		switch (choice) {
		case 1 :
			printf("your balance is %d\n\n",balance);
			break;
		case 2 :
			deposit();
			break;
		case 3 :
			withdraw();
			break;
		case 4 :
			return 0;
		default :
			printf("wrong choice\n\n");


		}
	}
}

void deposit() {
	int amount;
	printf("enter amount to deposit: ");
	scanf("%d",&amount);
	balance = balance + amount;
}

void withdraw() {
	int amount;
	printf("enter amount to withdraw : ");
	scanf("%d",&amount);
	balance-=amount;
}


