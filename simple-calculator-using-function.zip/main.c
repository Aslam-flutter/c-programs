/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int num1,num2;

void add();
void subst();
void divn();
void mult();

int main()
{
    int choice;
    printf("enter 2 numbers : ");
    scanf("%d %d",&num1,&num2);
    printf("1) add \n2) substraction \n3) division \n4) rmultiplicaton \n enter your choice : ");
    scanf("%d",&choice);
    if(choice==1){
        add();
    }else if (choice==2){
        subst();
    }else if (choice == 3){
        divn();
    }else if (choice == 4) {
        mult();
    }else {
        printf(" wrong choice");
    }
}

void add(){
    int result;
    result=num2+num1;
    printf("result is %d",result);
}
void subst(){
    int result;
    result=num1-num2;
    printf("result is %d",result);
}void divn(){
    int result;
    result=num1/num2;
    printf("result is %d",result);
}
void mult(){
   int result;
   result=num2*num1;
   printf("result is %d",result);
}