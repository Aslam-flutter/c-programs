/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    	int size,arr[100];
	printf("Enter size of array: ");
	scanf("%d",&size);

	printf("Enter elements of array: ");
	for(int i=0; i<size; i++) {
		scanf("%d",&arr[i]);
	}
	printf("array : ");
	for(int i=0; i<size; i++) {
		printf("%d ",arr[i]);
	}
	
	for(int i=0;i<size;i++){
	    for(int j=0;j<size-i-1;j++){
	        if(arr[j]>arr[j+1]){
	            
	            int temp=arr[j];
	            arr[j]=arr[j+1];
	            arr[j+1]=temp;
	        }
	    }
	}
// 	printf("\nsorted array : ");
// 	for(int i=0; i<size; i++) {
// 		printf("%d ",arr[i]);
// 	}

    printf("\nThe second last number in array: %d",arr[size-2]);
}
